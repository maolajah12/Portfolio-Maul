import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { BrutalStar, Barcode } from '../components/decor';

/* ============ ISI DATA KAMU DI SINI (semua masih CONTOH) ============ */

// Roadmap: pengalaman magang, urut dari yang paling lama (atas) ke terbaru (bawah)
const MAGANG = [
    {
        year: '2024', duration: '3 months', role: 'Posisi Magang', org: 'Nama Perusahaan Pertama', place: 'Medan',
        points: ['Tanggung jawab utama selama magang', 'Teknologi yang dipakai sehari-hari'],
        stack: ['PHP', 'Laravel', 'MySQL'], note: 'awal mula'
    },
    {
        year: '2025', duration: '6 months', role: 'Posisi Magang', org: 'Nama Perusahaan Kedua', place: 'Medan',
        points: ['Fitur yang kamu bangun dan untuk siapa', 'Teknologi yang dipakai sehari-hari', 'Satu hasil yang bisa diukur'],
        stack: ['React', 'Node.js', 'MySQL'], note: 'proyek favorit!'
    },
    {
        year: '2026', duration: '5 months', role: 'Posisi Magang', org: 'Nama Perusahaan Ketiga', place: 'Remote',
        points: ['Tanggung jawab utama selama magang', 'Tim tempat kamu bekerja dan perannya'],
        stack: ['Flutter', 'Firebase'], note: 'belajar banyak'
    },
];

// Kumpulan sertifikat (kartu di bawah roadmap). Isi url kalau ada tautannya.
const SERTIFIKAT = [
    { year: '2024', month: 'Nov', title: 'Nama Sertifikat Pertama', issuer: 'Nama Penerbit', credential: 'ID-0001', url: '' },
    { year: '2025', month: 'Agu', title: 'Nama Sertifikat Kedua', issuer: 'Nama Penerbit', credential: 'ID-0002', url: '' },
    { year: '2025', month: 'Des', title: 'Nama Sertifikat Ketiga', issuer: 'Nama Penerbit', credential: 'ID-0003', url: '' },
    { year: '2026', month: 'Okt', title: 'Nama Sertifikat Terbaru', issuer: 'Nama Penerbit', credential: 'ID-0004', url: '' },
];

const STAR8 = '50,0 61,35 98,35 68,57 79,91 50,70 21,91 32,57 2,35 39,35';
const STAR12 = '50,0 58,32 85,15 68,42 100,50 68,58 85,85 58,68 50,100 42,68 15,85 32,58 0,50 32,42 15,15 42,32';
const RED = '#ff1e56';
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

// ---------- Kata EXPERIENCE sebagai potongan kertas ala kolase (tanpa putaran) ----------
// Huruf berganti gaya: putih solid, kartu kertas berlakban, dan garis tepi. Tiap huruf miring sedikit,
// melayang pelan seperti mengapung (santai), dan melompat kecil kalau disentuh kursor.
// Lebar otomatis dipas ke ruang yang tersedia.
function CutoutWord({ word, pop = false, baseDelay = 0 }) {
    const outer = useRef(null);
    const inner = useRef(null);
    const [scale, setScale] = useState(1);

    useLayoutEffect(() => {
        const fit = () => {
            const o = outer.current, n = inner.current;
            if (!o || !n || !n.offsetWidth) return;
            setScale(Math.min(1, (o.clientWidth * 0.96) / n.offsetWidth));
        };
        fit();
        const ro = new ResizeObserver(fit);
        ro.observe(outer.current);
        document.fonts?.ready.then(fit);
        return () => ro.disconnect();
    }, [word]);

    return (
        <div ref={outer} aria-hidden="true" className="flex justify-center" style={{ width: '100%', padding: '1rem 0' }}>
            <div
                ref={inner}
                className="font-bbh font-black text-[9vw] sm:text-[8vw] md:text-[7.6vw] tracking-tighter uppercase"
                style={{ display: 'inline-flex', alignItems: 'center', whiteSpace: 'nowrap', lineHeight: 1.05, transform: `scale(${scale})`, transformOrigin: 'center' }}
            >
                {word.split('').map((ch, i) => {
                    const kind = i % 3;
                    const rot = (rnd(i, 21) - 0.5) * 9;
                    const dy = (rnd(i, 22) - 0.5) * 8;
                    const look =
                        kind === 0 ? { color: '#fff' }
                            : kind === 1 ? { color: '#0c0c0c', backgroundColor: '#f4f1ea', padding: '0 .1em', margin: '0 .03em' }
                                : { color: 'transparent', WebkitTextStroke: 'clamp(1.5px,.22vw,3.5px) #fff' };
                    return (
                        <span
                            key={i}
                            className="ex-letter"
                            style={{ display: 'inline-block', pointerEvents: 'auto', animation: pop ? `ex-pop .85s cubic-bezier(.2,1.5,.35,1) ${(baseDelay + i * 0.07).toFixed(2)}s both` : undefined }}
                        >
                            <span style={{ display: 'inline-block', transform: `translateY(${dy}%) rotate(${rot}deg)` }}>
                                <span className={`ex-glyph${kind === 1 ? ' crumpled-paper' : ''}`} style={{ display: 'inline-block', position: 'relative', animationDelay: `${(-i * 0.31).toFixed(2)}s`, ...look }}>
                                    {ch}
                                    {kind === 1 && <i aria-hidden="true" className="ex-tape" style={{ top: '-0.1em', width: '.45em', height: '.13em' }} />}
                                </span>
                            </span>
                        </span>
                    );
                })}
            </div>
        </div>
    );
}

/* =====================================================================
   HERO: "ME" (bintang merah, sama seperti penanda di roadmap) berjalan di jalan,
   garis tengah jalan menyala merah mengikuti langkahnya, di ujung jalan ia melambai,
   lalu jalan TERKOYAK seperti kertas dan memperlihatkan latar merah dengan kata EXPERIENCE.
   Bahasa visual diambil dari halaman ini: jalan gelap bergaris putus, bintang, lakban kuning,
   kertas kusut, spidol, barcode, bayangan keras.
   ===================================================================== */
const HERO_PHASES = ['walk', 'wave', 'crack', 'open', 'done'];
const WALK_MS = 3400, T_WAVE = 3500, T_CRACK = 5200, T_OPEN = 5900, T_DONE = 7600;
const STOP_X = 93; // posisi berhenti (% lebar layar)

// Garis retakan: [x%, posisi y sebagai pecahan tinggi jalan]. Tengah jalan = 0.5
const CRACK = [[0, 0.5], [6, 0.46], [12, 0.53], [19, 0.47], [26, 0.545], [33, 0.48], [41, 0.54], [50, 0.47], [58, 0.55], [66, 0.475], [74, 0.54], [82, 0.465], [90, 0.535], [100, 0.5]];
// Dua lempeng saling tumpang tindih (0.4-0.6) supaya tak ada celah sebelum retak.
// Sebelum retak: tepi lurus. Sesudah retak: tepi bergerigi yang pas satu sama lain.
const upperClip = (cracked) =>
    'polygon(0 0,100% 0,' + [...CRACK].reverse().map(([x, y]) => `${x}% ${cracked ? ((y / 0.6) * 100).toFixed(2) : 100}%`).join(',') + ')';
const lowerClip = (cracked) =>
    'polygon(' + CRACK.map(([x, y]) => `${x}% ${cracked ? (((y - 0.4) / 0.6) * 100).toFixed(2) : 0}%`).join(',') + ',100% 100%,0 100%)';

const rnd = (i, n) => { const x = Math.sin((i + 1) * 12.9898 + n * 78.233) * 43758.5453; return x - Math.floor(x); };
// Serpihan kertas/aspal yang beterbangan saat jalan koyak
const SHARDS = Array.from({ length: 14 }, (_, i) => ({
    left: 4 + rnd(i, 7) * 92, dx: (rnd(i, 8) - 0.5) * 9, dy: -(3 + rnd(i, 9) * 8), rot: (rnd(i, 10) - 0.5) * 500,
    w: 7 + rnd(i, 11) * 11, h: 4 + rnd(i, 12) * 6, delay: rnd(i, 13) * 0.4, c: ['#f2f2f2', '#fee440', '#1c1c1c'][i % 3],
}));
// Konfeti kertas saat kata muncul
const CONFETTI = Array.from({ length: 16 }, (_, i) => ({
    left: 8 + rnd(i, 1) * 84, dx: (rnd(i, 2) - 0.5) * 16, dy: -(4 + rnd(i, 3) * 11), rot: (rnd(i, 4) - 0.5) * 700,
    w: 7 + rnd(i, 5) * 9, delay: 0.15 + rnd(i, 6) * 0.6, c: ['#fff', '#fee440', '#0c0c0c'][i % 3],
}));

const ROAD_BG = 'radial-gradient(rgba(255,255,255,0.06) 1px, transparent 1.2px) 0 0/7px 7px, #0e0e0e';
const UNDER_BG = 'radial-gradient(rgba(0,0,0,0.22) 1.4px, transparent 1.7px) 0 0/9px 9px, #ff1e56';
const DASH = (c) => `repeating-linear-gradient(90deg, ${c} 0 26px, transparent 26px 50px)`;
const abs = { position: 'absolute' };
const T = 'calc(var(--wh) * 0.6 + var(--band) * 0.4)'; // tinggi ruang kosong di atas jalan

// Si "ME": kepala bintang merah (seperti penanda roadmap) + badan garis tebal.
// pose 'walk' = tampak samping, 'wave' = menghadap kita sambil melambai
function Walker({ pose }) {
    const common = { viewBox: '0 0 60 120', fill: 'none', stroke: '#fff', strokeWidth: 6, strokeLinecap: 'round', strokeLinejoin: 'round' };
    const style = { height: 'var(--wh)', width: 'auto', display: 'block', overflow: 'visible' };
    const head = (cx) => (
        <g>
            <g transform={`translate(${cx} 18) scale(0.34) translate(-50 -50)`}>
                <polygon points={STAR12} fill={RED} stroke="#0c0c0c" strokeWidth="6" strokeLinejoin="round" />
            </g>
            <text x={cx} y="21.5" textAnchor="middle" fontSize="9.5" fill="#fff" stroke="none" className="font-brush">ME</text>
        </g>
    );
    if (pose === 'walk') {
        return (
            <svg {...common} style={style} aria-hidden="true">
                <g className="ex-bob">
                    <g className="ex-limb ex-leg-b" stroke="#7d7d7d"><path d="M30 70 L30 104 L41 104" /></g>
                    <g className="ex-limb ex-arm-b" stroke="#7d7d7d"><path d="M30 38 L30 66" /></g>
                    <path d="M30 34 L30 70" strokeWidth="8" />
                    <g className="ex-limb ex-leg-a"><path d="M30 70 L30 104 L41 104" /></g>
                    <g className="ex-limb ex-arm-a"><path d="M30 38 L30 66" /></g>
                    {head(30)}
                </g>
            </svg>
        );
    }
    return (
        <svg {...common} style={style} aria-hidden="true">
            <g className="ex-bob-slow">
                <path d="M30 70 L21 104 L12 104" />
                <path d="M30 70 L39 104 L48 104" />
                <path d="M30 34 L30 70" strokeWidth="8" />
                <path d="M30 38 L19 64" />
                <path d="M30 38 L43 27" />
                <g className="ex-forearm"><path d="M43 27 L47 7" /></g>
                {head(30)}
            </g>
        </svg>
    );
}

function Spinner({ style, delay, spin, instant, children }) {
    return (
        <div aria-hidden="true" style={{ ...abs, pointerEvents: 'none', ...style, animation: instant ? 'none' : `ex-star-in .6s cubic-bezier(.2,1.6,.4,1) ${delay}s both` }}>
            <div style={{ width: '100%', height: '100%', animation: `ex-spin ${spin}s linear infinite` }}>{children}</div>
        </div>
    );
}

// Pernak-pernik kata EXPERIENCE (bahasa visual website): bintang, lakban, barcode, coretan spidol, konfeti kertas
function WordOrnaments({ instant, years }) {
    const sz = (a, b, c) => ({ width: `clamp(${a}px,${b}vw,${c}px)`, height: `clamp(${a}px,${b}vw,${c}px)` });
    return (
        <>
            {!instant && CONFETTI.map((s, i) => (
                <span
                    key={i}
                    aria-hidden="true"
                    style={{
                        ...abs, left: `${s.left}%`, top: '50%', width: s.w, height: s.w * 0.55, pointerEvents: 'none', background: s.c,
                        '--dx': `${s.dx}vw`, '--dy': `${s.dy}vw`, '--rot': `${s.rot}deg`,
                        animation: `ex-spark 1.4s ease-out ${s.delay.toFixed(2)}s both`,
                    }}
                />
            ))}

            <Spinner instant={instant} delay={0.9} spin={10} style={{ left: '-2%', top: '-34%', ...sz(30, 4.6, 72) }}>
                <BrutalStar color="white" points={12} className="w-full h-full" />
            </Spinner>
            <Spinner instant={instant} delay={1.15} spin={14} style={{ right: '-1%', top: '-36%', ...sz(24, 3.6, 56) }}>
                <svg viewBox="0 0 100 100" width="100%" height="100%" style={{ overflow: 'visible' }}>
                    <polygon points={STAR8} fill="#0c0c0c" stroke="#fff" strokeWidth="5" strokeLinejoin="round" />
                </svg>
            </Spinner>

            {/* lakban kuning, seperti di kartu */}
            <span aria-hidden="true" style={{ ...abs, left: '10%', top: '-30%', width: 'clamp(54px,6vw,96px)', height: 'clamp(16px,1.8vw,28px)', background: 'rgba(254,228,64,0.88)', transform: 'rotate(-7deg)', boxShadow: '0 2px 3px rgba(0,0,0,.35)', animation: instant ? 'none' : 'ex-star-in .5s cubic-bezier(.2,1.6,.4,1) 1s both' }} />
            <span aria-hidden="true" style={{ ...abs, right: '17%', top: '-32%', width: 'clamp(54px,6vw,96px)', height: 'clamp(16px,1.8vw,28px)', background: 'rgba(254,228,64,0.88)', transform: 'rotate(5deg)', boxShadow: '0 2px 3px rgba(0,0,0,.35)', animation: instant ? 'none' : 'ex-star-in .5s cubic-bezier(.2,1.6,.4,1) 1.1s both' }} />

            {/* catatan spidol */}
            <span className="font-marker" style={{ ...abs, left: '3%', bottom: '-30%', color: '#0c0c0c', fontSize: 'clamp(14px,1.9vw,30px)', transform: 'rotate(-4deg)', whiteSpace: 'nowrap', pointerEvents: 'none', animation: instant ? 'none' : 'ex-fade .5s ease-out 1.5s both' }}>
                {years}
            </span>

            {/* barcode */}
            <div aria-hidden="true" style={{ ...abs, right: '12%', bottom: '-30%', pointerEvents: 'none', animation: instant ? 'none' : 'ex-fade .5s ease-out 1.6s both' }}>
                <Barcode className="h-6 sm:h-8 opacity-90" />
            </div>

            {/* coretan spidol hitam di bawah kata */}
            <svg aria-hidden="true" viewBox="0 0 600 40" preserveAspectRatio="none" style={{ ...abs, left: '14%', width: '72%', bottom: '-14%', height: 'clamp(12px,1.8vw,28px)', pointerEvents: 'none', overflow: 'visible' }}>
                <path
                    d="M6 24 C 80 6, 150 36, 230 16 S 380 32, 450 12 S 560 28, 594 14"
                    fill="none" stroke="#0c0c0c" strokeWidth="8" strokeLinecap="round" pathLength="1"
                    style={{ strokeDasharray: 1, strokeDashoffset: 0, animation: instant ? 'none' : 'ex-draw .9s ease-out 1.3s both' }}
                />
            </svg>
        </>
    );
}

function HeroStage({ onReplay, years }) {
    const reduce = typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    const [phase, setPhase] = useState(reduce ? 'done' : 'walk');
    const [instant, setInstant] = useState(reduce);

    useEffect(() => {
        if (instant) return undefined;
        const ts = [[T_WAVE, 'wave'], [T_CRACK, 'crack'], [T_OPEN, 'open'], [T_DONE, 'done']].map(([ms, p]) => setTimeout(() => setPhase(p), ms));
        return () => ts.forEach(clearTimeout);
    }, [instant]);

    const idx = HERO_PHASES.indexOf(phase);
    const cracked = idx >= 2;
    const opened = idx >= 3;
    const done = phase === 'done';
    const pose = idx === 0 ? 'walk' : 'wave';

    const act = () => {
        if (done) onReplay();
        else { setInstant(true); setPhase('done'); }
    };

    const slabTransition = instant ? 'none' : 'transform .9s cubic-bezier(.2,1.2,.3,1)';
    const clipTransition = instant ? 'none' : 'clip-path .3s ease-out';

    return (
        <>
            <div
                role="button"
                tabIndex={0}
                aria-label={done ? 'Ulangi animasi' : 'Lewati animasi'}
                onClick={act}
                onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); act(); } }}
                className="ex-bleed focus-visible:outline-none"
                style={{
                    '--band': 'clamp(120px, 17vw, 300px)', '--wh': 'clamp(72px, 11vw, 170px)',
                    position: 'relative', height: `calc(${T} + var(--band) * 1.85 + 8px)`,
                    overflowX: 'clip', cursor: 'pointer', userSelect: 'none',
                    animation: phase === 'crack' && !instant ? 'ex-shake .12s linear 5' : 'none',
                }}
            >
                {/* LATAR MERAH di bawah jalan: terbuka dari celah retakan */}
                {opened && (
                    <div aria-hidden="true" style={{ ...abs, left: 0, right: 0, top: `calc(${T} - var(--band) * 0.14)`, height: 'calc(var(--band) * 1.28)', zIndex: 1, background: UNDER_BG, animation: instant ? 'none' : 'ex-under .8s cubic-bezier(.2,.9,.2,1) both' }} />
                )}

                {/* KATA EXPERIENCE */}
                {opened && (
                    <div className="ex-padx" style={{ ...abs, left: 0, right: 0, top: T, height: 'var(--band)', zIndex: 3, display: 'flex', alignItems: 'center', pointerEvents: 'none' }}>
                        <div style={{ position: 'relative', width: '100%' }}>
                            <div style={{ filter: 'drop-shadow(5px 5px 0 #0c0c0c)' }}>
                                <CutoutWord word="EXPERIENCE" pop={!instant} baseDelay={0.2} />
                            </div>
                            <WordOrnaments instant={instant} years={years} />
                        </div>
                    </div>
                )}

                {/* LEMPENG JALAN ATAS */}
                <div style={{ ...abs, left: 0, right: 0, top: T, height: 'calc(var(--band) * 0.6)', zIndex: 2, transformOrigin: '50% 100%', transition: slabTransition, transform: opened ? 'translateY(calc(var(--band) * -0.62)) rotate(-0.6deg)' : 'none' }}>
                    <div aria-hidden="true" style={{ ...abs, left: 0, right: 0, top: 7, bottom: -7, background: '#f2f2f2', clipPath: upperClip(cracked), opacity: cracked ? 1 : 0 }} />
                    <div style={{ ...abs, inset: 0, background: ROAD_BG, clipPath: upperClip(cracked), transition: clipTransition }}>
                        <div style={{ ...abs, left: 0, right: 0, top: 0, height: 3, background: 'rgba(255,255,255,0.4)' }} />
                    </div>
                </div>

                {/* LEMPENG JALAN BAWAH + si pejalan */}
                <div style={{ ...abs, left: 0, right: 0, top: `calc(${T} + var(--band) * 0.4)`, height: 'calc(var(--band) * 0.6)', zIndex: 5, transformOrigin: '50% 0', transition: slabTransition, transform: opened ? 'translateY(calc(var(--band) * 0.8)) rotate(0.5deg)' : 'none' }}>
                    <div aria-hidden="true" style={{ ...abs, left: 0, right: 0, top: -7, bottom: 7, background: '#f2f2f2', clipPath: lowerClip(cracked), opacity: cracked ? 1 : 0 }} />
                    <div style={{ ...abs, inset: 0, background: ROAD_BG, clipPath: lowerClip(cracked), transition: clipTransition }}>
                        <div style={{ ...abs, left: 0, right: 0, bottom: 0, height: 3, background: 'rgba(255,255,255,0.4)' }} />
                        {/* garis tengah putus-putus; menyala merah mengikuti langkah, persis seperti roadmap */}
                        <div style={{ ...abs, left: 0, right: 0, top: 'calc(var(--band) * 0.1 - 2px)', height: 4, background: DASH('rgba(255,255,255,0.55)'), opacity: cracked ? 0 : 1, transition: 'opacity .15s' }} />
                        <div style={{ ...abs, left: 0, top: 'calc(var(--band) * 0.1 - 2px)', height: 4, width: `${STOP_X}%`, background: DASH(RED), opacity: cracked ? 0 : 1, transition: 'opacity .15s', animation: instant ? 'none' : `ex-trail ${WALK_MS}ms cubic-bezier(.3,.05,.45,1) both` }} />
                    </div>

                    <div className="ex-walker" style={{ bottom: 'calc(var(--band) * 0.12)', animation: instant ? 'none' : `ex-walk-x ${WALK_MS}ms cubic-bezier(.3,.05,.45,1) both` }}>
                        <div aria-hidden="true" style={{ ...abs, left: '-30%', right: '-30%', bottom: -3, height: 7, borderRadius: '50%', background: 'rgba(0,0,0,0.65)', filter: 'blur(2px)' }} />
                        {idx >= 1 && (
                            <span key={opened ? 'b' : 'a'} className="ex-bubble crumpled-paper" style={instant ? { animation: 'none' } : undefined}>
                                <i aria-hidden="true" className="ex-tape" />
                                {opened ? 'ini dia!' : 'hai!'}
                            </span>
                        )}
                        <div key={pose} className={pose === 'wave' && !instant ? 'ex-hop' : undefined}>
                            <Walker pose={pose} />
                        </div>
                    </div>
                </div>

                {/* GARIS RETAKAN */}
                {phase === 'crack' && (
                    <svg aria-hidden="true" viewBox="0 0 100 100" preserveAspectRatio="none" style={{ ...abs, left: 0, width: '100%', top: T, height: 'var(--band)', zIndex: 6, pointerEvents: 'none', overflow: 'visible' }}>
                        <path
                            d={CRACK.map(([x, y], i) => `${i ? 'L' : 'M'}${x} ${y * 100}`).join(' ')}
                            fill="none" stroke={RED} strokeWidth="4" vectorEffect="non-scaling-stroke" strokeLinejoin="round" pathLength="1"
                            style={{ strokeDasharray: 1, filter: `drop-shadow(0 0 6px ${RED})`, animation: 'ex-draw .5s ease-out both' }}
                        />
                    </svg>
                )}

                {/* SERPIHAN */}
                {cracked && !instant && SHARDS.map((d, i) => (
                    <span
                        key={i}
                        aria-hidden="true"
                        style={{
                            ...abs, left: `${d.left}%`, top: `calc(${T} + var(--band) * 0.5)`, width: d.w, height: d.h, zIndex: 6, pointerEvents: 'none', background: d.c,
                            '--dx': `${d.dx}vw`, '--dy': `${d.dy}vw`, '--rot': `${d.rot}deg`,
                            animation: `ex-debris 1.1s ease-out ${d.delay.toFixed(2)}s both`,
                        }}
                    />
                ))}
            </div>
            <p className="text-center font-signature text-sm text-neutral-600 select-none -mt-2">
                {done ? 'klik untuk mengulang' : 'klik untuk melewati'}
            </p>
        </>
    );
}

function RoadHero({ years }) {
    const [runId, setRunId] = useState(0);
    return (
        <div>
            <style>{`
                .ex-padx { --padx: 20px; padding-left: var(--padx); padding-right: var(--padx); }
                .ex-bleed { margin-left: -20px; margin-right: -20px; }
                @media (min-width: 640px) { .ex-padx { --padx: 40px; } .ex-bleed { margin-left: -40px; margin-right: -40px; } }
                @media (min-width: 1024px) { .ex-padx { --padx: 80px; } .ex-bleed { margin-left: -80px; margin-right: -80px; } }
                @media (min-width: 1280px) { .ex-padx { --padx: 112px; } .ex-bleed { margin-left: -112px; margin-right: -112px; } }
                .ex-walker { position:absolute; left:${STOP_X}%; transform:translateX(-50%); z-index:2; }
                .ex-limb { transform-origin: 30px 70px; animation: ex-swing .84s ease-in-out infinite; }
                .ex-arm-a, .ex-arm-b { transform-origin: 30px 38px; }
                .ex-leg-b, .ex-arm-a { animation-delay: -.42s; }
                .ex-bob { animation: ex-bob .84s ease-in-out infinite; }
                .ex-bob-slow { animation: ex-bob-slow 1.2s ease-in-out infinite; }
                .ex-forearm { transform-origin: 43px 27px; animation: ex-wave .45s ease-in-out infinite alternate; }
                .ex-hop { animation: ex-hop .4s ease-out; }
                .ex-bubble { position:absolute; right:55%; top:-6px; white-space:nowrap; background-color:#f4f1ea; color:#0c0c0c;
                    box-shadow:4px 4px 0 #0c0c0c; padding:3px 12px; font-size:clamp(12px,1.3vw,18px); font-weight:800; transform:rotate(-4deg);
                    animation: ex-bubble .45s cubic-bezier(.2,1.6,.4,1) both; }
                .ex-tape { position:absolute; left:50%; top:-8px; width:34px; height:11px; background:rgba(254,228,64,.88); transform:translateX(-50%) rotate(3deg); }
                .ex-glyph { animation: ex-float 3.8s ease-in-out infinite; }
                .ex-letter:hover .ex-glyph { animation: ex-boing .55s ease-out; }
                @keyframes ex-float { 0%,100% { transform:translateY(0) rotate(-1.2deg); } 50% { transform:translateY(-7px) rotate(1.4deg); } }
                @keyframes ex-boing { 0% { transform:translateY(0) scale(1,1); } 30% { transform:translateY(-16px) scale(.94,1.1); }
                    60% { transform:translateY(0) scale(1.08,.9); } 100% { transform:translateY(0) scale(1,1); } }
                @keyframes ex-walk-x { from { left:-8%; } to { left:${STOP_X}%; } }
                @keyframes ex-trail { from { width:0; } to { width:${STOP_X}%; } }
                @keyframes ex-swing { 0%,100% { transform:rotate(-28deg); } 50% { transform:rotate(28deg); } }
                @keyframes ex-bob { 0%,50%,100% { transform:translateY(0); } 25%,75% { transform:translateY(-3px); } }
                @keyframes ex-bob-slow { 0%,100% { transform:translateY(0); } 50% { transform:translateY(-1.5px); } }
                @keyframes ex-wave { from { transform:rotate(-24deg); } to { transform:rotate(26deg); } }
                @keyframes ex-hop { 0% { transform:translateY(0); } 45% { transform:translateY(-12px); } 100% { transform:translateY(0); } }
                @keyframes ex-bubble { from { opacity:0; transform:rotate(-4deg) scale(.3); } to { opacity:1; transform:rotate(-4deg) scale(1); } }
                @keyframes ex-shake { 0%,100% { transform:translate(0,0); } 25% { transform:translate(-3px,2px); } 50% { transform:translate(3px,-2px); } 75% { transform:translate(-2px,-2px); } }
                @keyframes ex-draw { from { stroke-dashoffset:1; } to { stroke-dashoffset:0; } }
                @keyframes ex-under { from { clip-path:inset(46% 0 46% 0); } to { clip-path:inset(0 0 0 0); } }
                @keyframes ex-debris { 0% { opacity:0; transform:translate(0,0) rotate(0); } 10% { opacity:1; }
                    45% { opacity:1; transform:translate(var(--dx), var(--dy)) rotate(var(--rot)); }
                    100% { opacity:0; transform:translate(calc(var(--dx) * 1.5), calc(var(--dy) * -0.4)) rotate(calc(var(--rot) * 1.6)); } }
                @keyframes ex-pop { 0% { opacity:0; transform:translateY(80%) scale(.3) rotate(-16deg); }
                    60% { opacity:1; transform:translateY(-10%) scale(1.14) rotate(4deg); } 100% { opacity:1; transform:none; } }
                @keyframes ex-spark { 0% { opacity:0; transform:translate(0,0) scale(.3) rotate(0); } 12% { opacity:1; }
                    100% { opacity:0; transform:translate(var(--dx), var(--dy)) scale(1) rotate(var(--rot)); } }
                @keyframes ex-star-in { from { opacity:0; transform:scale(0) rotate(-90deg); } to { opacity:1; transform:scale(1) rotate(0); } }
                @keyframes ex-fade { from { opacity:0; } to { opacity:1; } }
                @keyframes ex-spin { to { transform:rotate(360deg); } }
            `}</style>
            <HeroStage key={runId} years={years} onReplay={() => setRunId((r) => r + 1)} />
        </div>
    );
}

// ---------- Kartu magang (kertas kusut) ----------
function InternshipCard({ stop, tilt }) {
    return (
        <article
            className="relative w-full max-w-md crumpled-paper text-black p-6 sm:p-7 shadow-[0_25px_60px_rgba(0,0,0,0.95)] border border-white/40 font-sans-tech"
            style={{ transform: `rotate(${tilt}deg)` }}
        >
            <span aria-hidden="true" className="absolute -top-3 left-1/2 -translate-x-1/2 w-20 h-6 bg-[#fee440]/85 rotate-2 shadow-sm" />
            {stop.note && (
                <span className="absolute -bottom-6 right-4 font-brush text-lg text-[#ff1e56] -rotate-3 pointer-events-none">{stop.note}</span>
            )}
            <div className="flex justify-between items-baseline font-bold text-sm">
                <span>{stop.year}</span>
                <span className="text-[11px] font-normal text-neutral-700">{stop.duration}</span>
            </div>
            <h3 className="font-display font-black text-xl sm:text-2xl leading-tight mt-1 text-neutral-900">{stop.role}</h3>
            <p className="text-sm font-medium text-neutral-800">{stop.org}</p>
            <p className="text-[11px] italic text-neutral-600 mb-3">internship, {stop.place}</p>
            <ul className="text-xs text-neutral-800 space-y-0.5 pl-2 border-l-2 border-black/30">
                {stop.points.map((p, i) => <li key={i}>- {p}</li>)}
            </ul>
            <div className="flex flex-wrap gap-1.5 mt-4">
                {stop.stack.map((t) => (
                    <span key={t} className="border border-black/50 px-2 py-0.5 text-[11px] font-bold">{t}</span>
                ))}
            </div>
            <div className="border-t-2 border-dashed border-black/40 my-4" />
            <Barcode className="h-7 opacity-80" />
        </article>
    );
}

// ---------- Tiket sertifikat (plastik abu-biru) ----------
function CertificateTicket({ stop, tilt = 0 }) {
    return (
        <article
            className="relative flex w-full bg-[#87939a] text-black shadow-[0_20px_50px_rgba(0,0,0,0.85)] border border-white/20 overflow-hidden font-sans-tech"
            style={{ transform: `rotate(${tilt}deg)` }}
        >
            <div aria-hidden="true" className="absolute inset-0 plastic-glare pointer-events-none z-10" />
            <span aria-hidden="true" className="absolute left-[4.5rem] -top-2.5 -translate-x-1/2 w-5 h-5 rounded-full bg-[#0c0c0c] z-20" />
            <span aria-hidden="true" className="absolute left-[4.5rem] -bottom-2.5 -translate-x-1/2 w-5 h-5 rounded-full bg-[#0c0c0c] z-20" />
            <div className="relative z-20 w-[4.5rem] shrink-0 flex flex-col items-center justify-center border-r-2 border-dashed border-black/50 py-5">
                <span className="font-marker text-[#ff1e56] text-sm -rotate-6">{stop.month}</span>
                <span className="font-display font-black text-2xl leading-none mt-1">{stop.year.slice(2)}</span>
            </div>
            <div className="relative z-20 p-4 sm:p-5 min-w-0 flex-1">
                <p className="text-[11px] italic text-neutral-800">sertifikat</p>
                <h3 className="font-display font-black text-base sm:text-lg leading-snug mt-0.5">{stop.title}</h3>
                <p className="text-xs font-medium text-neutral-900 mt-1">{stop.issuer}</p>
                <p className="text-[11px] text-neutral-800/80 mt-2">{stop.credential}</p>
                {stop.url && (
                    <a href={stop.url} target="_blank" rel="noreferrer"
                        className="inline-flex items-center gap-1 text-xs font-bold bg-black text-white px-3 py-1.5 mt-3 hover:bg-[#ff1e56] focus-visible:bg-[#ff1e56] focus-visible:outline-none transition-colors">
                        Lihat sertifikat <ArrowUpRight className="w-3.5 h-3.5" />
                    </a>
                )}
            </div>
            <BrutalStar color="white" points={12} className="w-8 h-8 absolute bottom-2 right-2 z-20 opacity-90" />
        </article>
    );
}

// ---------- Roadmap magang: jalan berkelok yang menyala mengikuti scroll ----------
function Road({ stops }) {
    const wrap = useRef(null);
    const rows = useRef([]);
    const road = useRef(null);
    const [geo, setGeo] = useState(null);
    const [pos, setPos] = useState({ x: 0, y: 0 });

    const measure = () => {
        const c = wrap.current;
        if (!c || rows.current.length !== stops.length || rows.current.some((r) => !r)) return;
        const w = c.clientWidth;
        const mobile = w < 768;
        const pts = rows.current.map((el, i) => ({
            x: mobile ? 20 : w / 2 + (i % 2 === 0 ? -38 : 38),
            y: el.offsetTop + el.offsetHeight / 2,
        }));
        setGeo({ w, h: c.clientHeight, mobile, pts });
    };

    useLayoutEffect(() => {
        measure();
        const ro = new ResizeObserver(measure);
        ro.observe(wrap.current);
        document.fonts?.ready.then(measure);
        return () => ro.disconnect();
    }, [stops.length]);

    useEffect(() => {
        let raf = 0;
        const track = () => {
            const c = wrap.current, p = road.current;
            if (!c || !p) return;
            const r = c.getBoundingClientRect();
            const t = clamp((window.innerHeight * 0.55 - r.top) / r.height, 0, 1);
            const pt = p.getPointAtLength(p.getTotalLength() * t);
            setPos({ x: pt.x, y: pt.y });
        };
        const on = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(track); };
        on();
        window.addEventListener('scroll', on, { passive: true });
        window.addEventListener('resize', on);
        return () => {
            cancelAnimationFrame(raf);
            window.removeEventListener('scroll', on);
            window.removeEventListener('resize', on);
        };
    }, [geo]);

    const d = useMemo(() => {
        if (!geo) return '';
        const all = [{ x: geo.pts[0].x, y: 0 }, ...geo.pts, { x: geo.pts[geo.pts.length - 1].x, y: geo.h }];
        let s = `M${all[0].x} ${all[0].y}`;
        for (let i = 1; i < all.length; i++) {
            const a = all[i - 1], b = all[i], m = (a.y + b.y) / 2;
            s += ` C${a.x} ${m} ${b.x} ${m} ${b.x} ${b.y}`;
        }
        return s;
    }, [geo]);

    return (
        <div ref={wrap} className="relative">
            {geo && (
                <svg aria-hidden="true" className="absolute inset-0 pointer-events-none z-0" width={geo.w} height={geo.h}>
                    <defs>
                        <clipPath id="road-reached"><rect x="0" y="0" width={geo.w} height={pos.y} /></clipPath>
                    </defs>
                    <path d={d} fill="none" stroke="rgba(255,255,255,0.35)" strokeWidth={geo.mobile ? 26 : 38} strokeLinecap="round" />
                    <path d={d} fill="none" stroke="#0c0c0c" strokeWidth={geo.mobile ? 23 : 35} strokeLinecap="round" />
                    <path ref={road} d={d} fill="none" stroke="rgba(255,255,255,0.55)" strokeWidth="2" strokeDasharray="9 11" />
                    <path d={d} fill="none" stroke={RED} strokeWidth="3.5" strokeDasharray="9 11" clipPath="url(#road-reached)" />

                    {geo.pts.map((p, i) => {
                        const cardRight = i % 2 === 0;
                        const edge = geo.mobile ? 44 : geo.w / 2 + (cardRight ? 70 : -70);
                        const on = pos.y >= p.y;
                        return (
                            <g key={i}>
                                <line x1={p.x} y1={p.y} x2={edge} y2={p.y} stroke={on ? RED : 'rgba(255,255,255,0.3)'} strokeWidth="2" strokeDasharray="3 5" />
                                <polygon points={STAR8} transform={`translate(${p.x - 17} ${p.y - 17}) scale(0.34)`} fill={on ? RED : '#fff'} stroke="#0c0c0c" strokeWidth="6" strokeLinejoin="round" />
                            </g>
                        );
                    })}

                    <g transform={`translate(${pos.x} ${pos.y})`}>
                        <polygon points={STAR12} transform="translate(-24 -24) scale(0.48)" fill={RED} stroke="#0c0c0c" strokeWidth="5" strokeLinejoin="round" />
                        <text textAnchor="middle" dy="5" fontSize="13" fill="#fff" className="font-brush">ME</text>
                    </g>
                </svg>
            )}

            <ol className="relative z-10">
                {stops.map((s, i) => {
                    const cardRight = i % 2 === 0;
                    const reached = geo && pos.y >= geo.pts[i].y;
                    const tilt = i % 4 < 2 ? -1.2 : 1.2;
                    return (
                        <li
                            key={i}
                            ref={(el) => (rows.current[i] = el)}
                            className="grid grid-cols-1 md:grid-cols-[1fr_140px_1fr] items-center py-10 md:py-14 pl-12 md:pl-0"
                        >
                            <div className={`hidden md:flex md:row-start-1 ${cardRight ? 'md:col-start-1 justify-end' : 'md:col-start-3 justify-start'}`}>
                                <span className={`font-marker text-5xl lg:text-6xl -rotate-6 transition-colors duration-500 ${reached ? 'text-[#ff1e56]' : 'text-white/80'}`}>
                                    {s.year}
                                </span>
                            </div>
                            <div className={`md:row-start-1 flex ${cardRight ? 'md:col-start-3 md:justify-start' : 'md:col-start-1 md:justify-end'}`}>
                                <InternshipCard stop={s} tilt={tilt} />
                            </div>
                        </li>
                    );
                })}
            </ol>
        </div>
    );
}

// ---------- HALAMAN EXPERIENCE ----------
export default function ExperiencePage({ onHire }) {
    return (
        <main className="relative z-10 w-full max-w-[1800px] mx-auto px-5 sm:px-10 lg:px-20 xl:px-28 pt-28 pb-32 animate-fade-in">
            <h1 className="sr-only">Experience</h1>
            <RoadHero years={`${MAGANG[0].year} - ${MAGANG[MAGANG.length - 1].year}`} />

            <div className="flex flex-wrap items-center justify-center gap-x-8 gap-y-2 mt-6 mb-10 font-sans-tech text-sm text-neutral-400 select-none">
                <span className="flex items-center gap-2"><BrutalStar color="white" className="w-4 h-4" /> {MAGANG.length} pengalaman magang</span>
                <a href="#sertifikat" className="flex items-center gap-2 hover:text-white focus-visible:text-white focus-visible:outline-none transition-colors">
                    <span className="w-3.5 h-3.5 rounded-full border-2 border-white" /> {SERTIFIKAT.length} sertifikat di bawah
                </a>
                <span className="font-signature text-lg text-neutral-500">scroll untuk mengikuti jalannya</span>
            </div>

            {/* ROADMAP MAGANG */}
            <Road stops={MAGANG} />

            {/* KUMPULAN SERTIFIKAT */}
            <section id="sertifikat" className="mt-24 scroll-mt-28">
                <div className="flex items-end gap-4 mb-10 select-none">
                    <h2 className="font-marker text-3xl sm:text-4xl text-white -rotate-3">Sertifikat</h2>
                    <span className="font-signature text-xl text-neutral-500 pb-1">{SERTIFIKAT.length} koleksi</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-x-8 gap-y-10">
                    {SERTIFIKAT.map((s, i) => (
                        <CertificateTicket key={i} stop={s} tilt={i % 2 === 0 ? -1 : 1} />
                    ))}
                </div>
            </section>

            <div className="text-center mt-24 select-none">
                <p className="font-brush text-3xl text-[#ff1e56] -rotate-2 inline-block">pemberhentian berikutnya?</p>
                <div className="mt-5">
                    <button
                        onClick={onHire}
                        className="px-6 py-2.5 rounded-full bg-white text-black hover:bg-[#ff1e56] hover:text-white focus-visible:bg-[#ff1e56] focus-visible:text-white focus-visible:outline-none font-sans-tech font-bold text-sm transition-colors"
                    >
                        Hire Maulana
                    </button>
                </div>
            </div>
        </main>
    );
}